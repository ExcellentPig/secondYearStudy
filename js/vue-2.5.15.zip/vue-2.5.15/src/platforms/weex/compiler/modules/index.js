import klass from './class'
import style from './style'
import props from './props'
import append from './append'
import recycleList from './recycle-list/index'

export default [
  recycleList,
  klass,
  style,
  props,
  append
]
